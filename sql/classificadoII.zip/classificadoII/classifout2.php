<HTML>
<HEAD>
<TITLE>Classificados - home page</TITLE>
</HEAD>
<BODY  TEXT="#000000" LINK="#0000ff" bgcolor="#FFFFFF">
<BASEFONT SIZE=4>
<?php 
// Carrega o arquivo classif.dat em um array e o exibe
 switch ($_GET['classe']) {
    case 1: $vetor_arquivo = file("clacarros.dat");
            print ("<H2><STRONG><I> Classificados - Carros </I></STRONG></H2> <P>");
            break;
    case 2: $vetor_arquivo = file("clamotos.dat");
            print ("<H2><STRONG><I> Classificados - Motos </I></STRONG></H2> <P>");
            break;
    case 3: $vetor_arquivo = file("claimoveis.dat");
            print ("<H2><STRONG><I> Classificados - Imóveis </I></STRONG></H2> <P>");
            break;
    case 4: $vetor_arquivo = file("clainfo.dat");
            print ("<H2><STRONG><I> Classificados - Informática </I></STRONG></H2> <p>");
            break;
    case 5: $vetor_arquivo = file("claeletro.dat");
            print ("<H2><STRONG><I> Classificados - Eletro-eletronicos </I></STRONG></H2> <P>");
            break;
    case 6: $vetor_arquivo = file("cladiversos.dat");
            print ("<H2><STRONG><I> Classificados - Diversos </I></STRONG></H2> <P>");
            break;
 } 
 while ( list( $num_linha, $linha ) = each( $vetor_arquivo ) ) { 
    print ( $linha); 
 } 
?>
</BODY>
</HTML>
